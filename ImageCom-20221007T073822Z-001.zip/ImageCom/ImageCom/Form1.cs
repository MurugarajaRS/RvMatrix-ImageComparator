﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageCom
{
    public partial class ImageComparator : Form
    {
        public ImageComparator()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ImageCom_Click(object sender, EventArgs e)
        {
            //ImageCom frm = new ImageCom();
            Form3 frm = new Form3();
            frm.Show(this);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
