﻿
namespace ImageCom
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.t = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelcolor = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textboxh = new System.Windows.Forms.TextBox();
            this.textboxw = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Label();
            this.pi = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btngi = new System.Windows.Forms.Label();
            this.btns = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pi2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btngi2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_pencil = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.pi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pi2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // t
            // 
            this.t.Location = new System.Drawing.Point(986, 829);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(160, 73);
            this.t.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.labelcolor);
            this.panel2.Location = new System.Drawing.Point(282, 803);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(25, 24);
            this.panel2.TabIndex = 10;
            // 
            // labelcolor
            // 
            this.labelcolor.AutoSize = true;
            this.labelcolor.BackColor = System.Drawing.Color.Black;
            this.labelcolor.Location = new System.Drawing.Point(2, 0);
            this.labelcolor.Name = "labelcolor";
            this.labelcolor.Size = new System.Drawing.Size(20, 17);
            this.labelcolor.TabIndex = 2;
            this.labelcolor.Text = "   ";
            this.labelcolor.Click += new System.EventHandler(this.ClickA);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(1550, 773);
            this.trackBar1.Maximum = 90;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(213, 56);
            this.trackBar1.TabIndex = 9;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(1354, 750);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(125, 24);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.Text = "Arial";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form3_KeyPress);
            // 
            // textboxh
            // 
            this.textboxh.Location = new System.Drawing.Point(1056, 748);
            this.textboxh.Name = "textboxh";
            this.textboxh.Size = new System.Drawing.Size(125, 22);
            this.textboxh.TabIndex = 7;
            this.textboxh.Text = "50";
            this.textboxh.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form3_KeyPress);
            // 
            // textboxw
            // 
            this.textboxw.Location = new System.Drawing.Point(784, 746);
            this.textboxw.Name = "textboxw";
            this.textboxw.Size = new System.Drawing.Size(125, 22);
            this.textboxw.TabIndex = 6;
            this.textboxw.Text = "100";
            this.textboxw.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form3_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(169, 807);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1532, 750);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Font Size";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1238, 750);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Font Family";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(950, 748);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Height";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(685, 748);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width";
            // 
            // btnadd
            // 
            this.btnadd.AutoSize = true;
            this.btnadd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(483, 746);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(180, 22);
            this.btnadd.TabIndex = 0;
            this.btnadd.Text = "Add your Comments";
            this.btnadd.Click += new System.EventHandler(this.ClickA);
            // 
            // pi
            // 
            this.pi.AutoScroll = true;
            this.pi.BackColor = System.Drawing.Color.White;
            this.pi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pi.Controls.Add(this.pictureBox1);
            this.pi.Location = new System.Drawing.Point(21, 19);
            this.pi.Name = "pi";
            this.pi.Size = new System.Drawing.Size(869, 703);
            this.pi.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(862, 695);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // btngi
            // 
            this.btngi.AutoSize = true;
            this.btngi.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btngi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngi.Location = new System.Drawing.Point(15, 744);
            this.btngi.Name = "btngi";
            this.btngi.Size = new System.Drawing.Size(125, 22);
            this.btngi.TabIndex = 11;
            this.btngi.Text = "Upload Image";
            this.btngi.Click += new System.EventHandler(this.ClickA);
            // 
            // btns
            // 
            this.btns.AutoSize = true;
            this.btns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btns.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns.Location = new System.Drawing.Point(864, 807);
            this.btns.Name = "btns";
            this.btns.Size = new System.Drawing.Size(52, 22);
            this.btns.TabIndex = 12;
            this.btns.Text = "Save";
            this.btns.Click += new System.EventHandler(this.ClickA);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pi2
            // 
            this.pi2.AutoScroll = true;
            this.pi2.BackColor = System.Drawing.Color.White;
            this.pi2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pi2.Controls.Add(this.pictureBox2);
            this.pi2.Location = new System.Drawing.Point(896, 19);
            this.pi2.Name = "pi2";
            this.pi2.Size = new System.Drawing.Size(929, 703);
            this.pi2.TabIndex = 13;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(921, 695);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // btngi2
            // 
            this.btngi2.AutoSize = true;
            this.btngi2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btngi2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngi2.Location = new System.Drawing.Point(1348, 829);
            this.btngi2.Name = "btngi2";
            this.btngi2.Size = new System.Drawing.Size(125, 22);
            this.btngi2.TabIndex = 14;
            this.btngi2.Text = "Upload Image";
            this.btngi2.Click += new System.EventHandler(this.ClickA);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(173, 744);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 22);
            this.label1.TabIndex = 16;
            this.label1.Text = "Zoom In";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(284, 744);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 22);
            this.label7.TabIndex = 17;
            this.label7.Text = "Zoom Out";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // btn_pencil
            // 
            this.btn_pencil.AutoSize = true;
            this.btn_pencil.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btn_pencil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pencil.Location = new System.Drawing.Point(402, 744);
            this.btn_pencil.Name = "btn_pencil";
            this.btn_pencil.Size = new System.Drawing.Size(63, 22);
            this.btn_pencil.TabIndex = 18;
            this.btn_pencil.Text = "Pencil";
            this.btn_pencil.Click += new System.EventHandler(this.btn_pencil_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1924, 904);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn_pencil);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textboxh);
            this.Controls.Add(this.btngi2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textboxw);
            this.Controls.Add(this.pi2);
            this.Controls.Add(this.btns);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btngi);
            this.Controls.Add(this.pi);
            this.Controls.Add(this.t);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnadd);
            this.Name = "Form3";
            this.Text = "Upload Image Comparator";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            this.Click += new System.EventHandler(this.ClickA);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form3_KeyPress);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.pi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pi2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel t;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label btnadd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textboxh;
        private System.Windows.Forms.TextBox textboxw;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelcolor;
        private System.Windows.Forms.Panel pi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label btngi;
        private System.Windows.Forms.Label btns;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel pi2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label btngi2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label btn_pencil;
    }
}