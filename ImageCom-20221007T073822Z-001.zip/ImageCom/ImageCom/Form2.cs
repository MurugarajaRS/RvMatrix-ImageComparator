﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageCom
{
    public partial class ImageCom : Form
    {
        private Bitmap _bmp = null;
        private int _x;
        private int _y;
        private GraphicsPath _gPath = null;
        private bool _moving;
        private bool _erasing;
        public ImageCom()
        {
            InitializeComponent();

            //or set location and size (make sure the panel's AutoScroll property is set to true)

        }


        private void ImageCom_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog upload = new OpenFileDialog())
            {
                //  upload.Filter = "Txt Files|*.txt";
                upload.Title = "Select File";
                upload.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
                if (upload.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = new Bitmap(upload.FileName);
                }
            }
        }
        private void ZoomInOut(bool zoom)
        {
            //Zoom ratio by which the images will be zoomed by default
            int zoomRatio = 10;
            //Set the zoomed width and height
            int widthZoom = pictureBox1.Width * zoomRatio / 100;
            int heightZoom = pictureBox1.Height * zoomRatio / 100;
            //zoom = true --> zoom in
            //zoom = false --> zoom out
            if (!zoom)
            {
                widthZoom *= -1;
                heightZoom *= -1;
            }
            //Add the width and height to the picture box dimensions
            pictureBox1.Width += widthZoom;
            pictureBox1.Height += heightZoom;

        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            ZoomInOut(true);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            ZoomInOut(false);
        }
        //protected override void OnMouseWheel(MouseEventArgs e)
        //{
        //    if (e.Delta != 0)
        //    {
        //        if (e.Delta <= 0)
        //        {
        //            //set minimum size to zoom
        //            if (pictureBox1.Width < 50)
        //                // lbl_Zoom.Text = pictureBox1.Image.Size; 
        //                return;
        //        }
        //        else
        //        {
        //            //set maximum size to zoom
        //            if (pictureBox1.Width > 1000)
        //                return;
        //        }
        //        pictureBox1.Width += Convert.ToInt32(pictureBox1.Width * e.Delta / 1000);
        //        pictureBox1.Height += Convert.ToInt32(pictureBox1.Height * e.Delta / 1000);
        //    }
        //}


        //private void pictureBox1_Paint(object sender, PaintEventArgs e)
        //{
        //    e.Graphics.DrawLine(
        //        new Pen(Color.Red, 2f),
        //        new Point(0, 0),
        //        new Point(pictureBox1.Size.Width, pictureBox1.Size.Height));

        //    e.Graphics.DrawEllipse(
        //        new Pen(Color.Red, 2f),
        //        0, 0, pictureBox1.Size.Width, pictureBox1.Size.Height);
        //}

        public int x1, y1, x2, y2, x3, y3, im = 0;

        bool draw = false;

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                //draw out our current bitmap
                if (_bmp != null)
                    e.Graphics.DrawImage(_bmp, 0, 0);

                if (_gPath != null)
                {
                    if (_erasing)
                    {
                        //we draw with CompositingMode.SourceCopy - a transparent Color
                        //will first appear as black, so we draw thee temporary stuff in the panel's BackColor
                        e.Graphics.CompositingMode = CompositingMode.SourceCopy;

                        using (Pen pen = new Pen(color,3))
                            e.Graphics.DrawPath(pen, _gPath);
                    }
                    else
                    {
                        //set a better SmoothingMode
                        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                        using (Pen pen = new Pen(color,3))
                            e.Graphics.DrawPath(pen, _gPath);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        int s = 3;
        Color color = Color.Red;



        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Left || e.Button == MouseButtons.Right)
                {
                    //set the start-point
                    _x = e.X;
                    _y = e.Y;

                    //ensure that the GraphicsPath is instanciated
                    if (_gPath == null)
                    {
                        _gPath = new GraphicsPath();
                    }

                    if (e.Button == MouseButtons.Right)
                        _erasing = true;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                if (_gPath != null)
                {
                    //draw the current Path to the Bitmap
                    if (_bmp != null && _moving)
                    {
                        using (Graphics g = Graphics.FromImage(_bmp))
                        {
                            if (e.Button == System.Windows.Forms.MouseButtons.Left)
                            {
                                g.SmoothingMode = SmoothingMode.AntiAlias;
                                using (Pen pen = new Pen(color, 3))
                                    g.DrawPath(pen, _gPath);
                            }
                            else if (e.Button == MouseButtons.Right)
                            {
                                g.CompositingMode = CompositingMode.SourceCopy;
                                using (Pen pen = new Pen(color, 3))
                                    g.DrawPath(pen, _gPath);
                            }
                        }
                    }

                    //dispose the path-object
                    _gPath.Dispose();
                    _gPath = null;

                    //draw out the bitmap
                   // p.Invalidate();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Left || e.Button == MouseButtons.Right)
                {
                    //add a line to the path from the previous point to the current point
                    _gPath.AddLine(new Point(_x, _y), new Point(e.X, e.Y));
                    //set the current point to thje new values
                    _x = e.X;
                    _y = e.Y;

                    //call the draw-method for the needed part
                    RectangleF r = _gPath.GetBounds();
                    r.Inflate(3, 3);
                    using (Region reg = new Region(r))
                       // p.Invalidate(reg);
                    _moving = true;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //private void pictureBox1_Paint_1(object sender, PaintEventArgs e)
        //{
        //    e.Graphics.DrawLine(
        //        new Pen(Color.Red, 2f),
        //        new Point(0, 0),
        //        new Point(pictureBox1.Size.Width, pictureBox1.Size.Height));

        //    e.Graphics.DrawEllipse(
        //        new Pen(Color.Red,2f),
        //        0,0, pictureBox1.Size.Width,pictureBox1.Size.Height);
        //}

        public Color blkcolor = Color.Red;

        //private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        //{
        //First Line
        //  Graphics grps = pictureBox1.CreateGraphics();
        //Pen pen = new Pen(blkcolor, 3);
        //if (im % 3 == 0)
        //{
        //    x1 = e.X;
        //    y1 = e.Y;
        //}
        //else if (im % 3 == 1)
        //{
        //    x2 = e.X;
        //    y2 = e.Y;
        //    grps.DrawLine(pen, x1, y1, x2, y2);
        //}
        //else if (im % 3 == 2)
        //{
        //    x3 = e.X;
        //    y3 = e.Y;
        //    grps.DrawLine(pen, x1, y1, x3, y3);
        //    grps.DrawLine(pen, x2, y2, x3, y3);
        //}
        //im++;

        //grps.DrawLine(
        //   new Pen(Color.Red, 2f),
        //   new Point(0, 0),
        //   new Point(pictureBox1.Size.Width, pictureBox1.Size.Height));

        //grps.DrawEllipse(
        //    new Pen(Color.Red, 2f),
        //    0, 0, pictureBox1.Size.Width, pictureBox1.Size.Height);
        //Two draw
        //float zoom = 1f * pictureBox1.ClientSize.Width / pictureBox1.Image.Width;
        //Graphics g = pictureBox1.CreateGraphics();

        //g.ScaleTransform(zoom, zoom);

        //// now do your drawing..
        //// here just a demo ellipse and a line..
        //Rectangle rect = panel1.ClientRectangle;
        //g.DrawEllipse(Pens.Firebrick, rect);
        //using (Pen pen = new Pen(Color.DarkBlue, 4f)) g.DrawLine(pen, 22, 22, 88, 88);
        //}


    }
}
